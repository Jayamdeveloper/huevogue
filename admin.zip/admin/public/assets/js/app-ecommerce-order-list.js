"use strict";
$((function() {
    let e, t, a;
    isDarkStyle ? (e = config.colors_dark.borderColor, t = config.colors_dark.bodyBg, a = config.colors_dark.headingColor) : (e = config.colors.borderColor, t = config.colors.bodyBg, a = config.colors.headingColor);
    var s = $(".datatables-order"),
        r = {
            1: {
                title: "Dispatched",
                class: "bg-label-warning"
            },
            2: {
                title: "Delivered",
                class: "bg-label-success"
            },
            3: {
                title: "Out for Delivery",
                class: "bg-label-primary"
            },
            4: {
                title: "Ready to Pickup",
                class: "bg-label-info"
            }
        },
        n = {
            1: {
                title: "Paid",
                class: "text-success"
            },
            2: {
                title: "Pending",
                class: "text-warning"
            },
            3: {
                title: "Failed",
                class: "text-danger"
            },
            4: {
                title: "Cancelled",
                class: "text-secondary"
            }
        };
    if (s.length) {
        var o = s.DataTable({
            ajax: assetsPath + "json/ecommerce-customer-order.json",
            columns: [{
                data: "id"
            }, {
                data: "id"
            }, {
                data: "order"
            }, {
                data: "date"
            }, {
                data: "customer"
            }, {
                data: "payment"
            }, {
                data: "status"
            }, {
                data: "method"
            }, {
                data: ""
            }],
            columnDefs: [{
                className: "control",
                searchable: !1,
                orderable: !1,
                responsivePriority: 2,
                targets: 0,
                render: function(e, t, a, s) {
                    return ""
                }
            }, {
                targets: 1,
                orderable: !1,
                checkboxes: {
                    selectAllRender: '<input type="checkbox" class="form-check-input">'
                },
                render: function() {
                    return '<input type="checkbox" class="dt-checkboxes form-check-input" >'
                },
                searchable: !1
            }, {
                targets: 2,
                render: function(e, t, a, s) {
                    var r = a.order;
                    return '<a href=" ' + baseUrl + 'app/ecommerce/order/details"><span class="fw-medium">#' + r + "</span></a>"
                }
            }, {
                targets: 3,
                render: function(e, t, a, s) {
                    var r = new Date(a.date),
                        n = a.time.substring(0, 5);
                    return '<span class="text-nowrap">' + r.toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                        time: "numeric"
                    }) + ", " + n + "</span>"
                }
            }, {
                targets: 4,
                responsivePriority: 1,
                render: function(e, t, a, s) {
                    var r = a.customer,
                        n = a.email,
                        o = a.avatar;
                    if (o) var i = '<img src="' + assetsPath + "img/avatars/" + o + '" alt="Avatar" class="rounded-circle">';
                    else {
                        var l = ["success", "danger", "warning", "info", "dark", "primary", "secondary"][Math.floor(6 * Math.random())],
                            c = (r = a.customer).match(/\b\w/g) || [];
                        i = '<span class="avatar-initial rounded-circle bg-label-' + l + '">' + (c = ((c.shift() || "") + (c.pop() || "")).toUpperCase()) + "</span>"
                    }
                    return '<div class="d-flex justify-content-start align-items-center order-name text-nowrap"><div class="avatar-wrapper"><div class="avatar me-2">' + i + '</div></div><div class="d-flex flex-column"><h6 class="m-0"><a href="' + baseUrl + 'pages/profile-user" class="text-body">' + r + '</a></h6><small class="text-muted">' + n + "</small></div></div>"
                }
            }, {
                targets: 5,
                render: function(e, t, a, s) {
                    var r = a.payment,
                        o = n[r];
                    return o ? '<h6 class="mb-0 w-px-100 ' + o.class + '"><i class="bx bxs-circle fs-tiny me-2"></i>' + o.title + "</h6>" : e
                }
            }, {
                targets: -3,
                render: function(e, t, a, s) {
                    var n = a.status;
                    return '<span class="badge px-2 ' + r[n].class + '" text-capitalized>' + r[n].title + "</span>"
                }
            }, {
                targets: -2,
                render: function(e, t, a, s) {
                    var r = a.method,
                        n = a.method_number;
                    return "paypal_logo" == r && (n = "@gmail.com"), '<div class="d-flex align-items-center text-nowrap"><img src="' + assetsPath + "img/icons/payments/" + r + '.png" alt="' + r + '" class="me-2" width="16"><span><i class="bx bx-dots-horizontal-rounded"></i>' + n + "</span></div>"
                }
            }, {
                targets: -1,
                title: "Actions",
                searchable: !1,
                orderable: !1,
                render: function(e, t, a, s) {
                    return '<div class="d-flex justify-content-sm-center align-items-sm-center"><button class="btn btn-sm btn-icon dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button><div class="dropdown-menu dropdown-menu-end m-0"><a href=" ' + baseUrl + 'app/ecommerce/order/details" class="dropdown-item">View</a><a href="javascript:0;" class="dropdown-item delete-record">Delete</a></div></div>'
                }
            }],
            order: [3, "asc"],
            dom: '<"card-header d-flex flex-column flex-md-row align-items-start align-items-md-center"<"ms-n2"f><"d-flex align-items-md-center justify-content-md-end mt-2 mt-md-0"l<"dt-action-buttons"B>>>t<"row mx-2"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
            lengthMenu: [10, 40, 60, 80, 100],
            language: {
                sLengthMenu: "_MENU_",
                search: "",
                searchPlaceholder: "Search Order",
                info: "Displaying _START_ to _END_ of _TOTAL_ entries"
            },
            buttons: [{
                extend: "collection",
                className: "btn btn-label-secondary dropdown-toggle",
                text: '<i class="bx bx-export me-1"></i>Export',
                buttons: [{
                    extend: "print",
                    text: '<i class="bx bx-printer me-2" ></i>Print',
                    className: "dropdown-item",
                    exportOptions: {
                        columns: [2, 3, 4, 5, 6, 7],
                        format: {
                            body: function(e, t, a) {
                                if (e.length <= 0) return e;
                                var s = $.parseHTML(e),
                                    r = "";
                                return $.each(s, (function(e, t) {
                                    void 0 !== t.classList && t.classList.contains("order-name") ? r += t.lastChild.firstChild.textContent : void 0 === t.innerText ? r += t.textContent : r += t.innerText
                                })), r
                            }
                        }
                    },
                    customize: function(s) {
                        $(s.document.body).css("color", a).css("border-color", e).css("background-color", t), $(s.document.body).find("table").addClass("compact").css("color", "inherit").css("border-color", "inherit").css("background-color", "inherit")
                    }
                }, {
                    extend: "csv",
                    text: '<i class="bx bx-file me-2" ></i>Csv',
                    className: "dropdown-item",
                    exportOptions: {
                        columns: [2, 3, 4, 5, 6, 7],
                        format: {
                            body: function(e, t, a) {
                                if (e.length <= 0) return e;
                                var s = $.parseHTML(e),
                                    r = "";
                                return $.each(s, (function(e, t) {
                                    void 0 !== t.classList && t.classList.contains("order-name") ? r += t.lastChild.firstChild.textContent : void 0 === t.innerText ? r += t.textContent : r += t.innerText
                                })), r
                            }
                        }
                    }
                }, {
                    extend: "excel",
                    text: '<i class="bx bxs-file-export me-2"></i>Excel',
                    className: "dropdown-item",
                    exportOptions: {
                        columns: [2, 3, 4, 5, 6, 7],
                        format: {
                            body: function(e, t, a) {
                                if (e.length <= 0) return e;
                                var s = $.parseHTML(e),
                                    r = "";
                                return $.each(s, (function(e, t) {
                                    void 0 !== t.classList && t.classList.contains("order-name") ? r += t.lastChild.firstChild.textContent : void 0 === t.innerText ? r += t.textContent : r += t.innerText
                                })), r
                            }
                        }
                    }
                }, {
                    extend: "pdf",
                    text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
                    className: "dropdown-item",
                    exportOptions: {
                        columns: [2, 3, 4, 5, 6, 7],
                        format: {
                            body: function(e, t, a) {
                                if (e.length <= 0) return e;
                                var s = $.parseHTML(e),
                                    r = "";
                                return $.each(s, (function(e, t) {
                                    void 0 !== t.classList && t.classList.contains("order-name") ? r += t.lastChild.firstChild.textContent : void 0 === t.innerText ? r += t.textContent : r += t.innerText
                                })), r
                            }
                        }
                    }
                }, {
                    extend: "copy",
                    text: '<i class="bx bx-copy me-2" ></i>Copy',
                    className: "dropdown-item",
                    exportOptions: {
                        columns: [2, 3, 4, 5, 6, 7],
                        format: {
                            body: function(e, t, a) {
                                if (e.length <= 0) return e;
                                var s = $.parseHTML(e),
                                    r = "";
                                return $.each(s, (function(e, t) {
                                    void 0 !== t.classList && t.classList.contains("order-name") ? r += t.lastChild.firstChild.textContent : void 0 === t.innerText ? r += t.textContent : r += t.innerText
                                })), r
                            }
                        }
                    }
                }]
            }],
            responsive: {
                details: {
                    display: $.fn.dataTable.Responsive.display.modal({
                        header: function(e) {
                            return "Details of " + e.data().customer
                        }
                    }),
                    type: "column",
                    renderer: function(e, t, a) {
                        var s = $.map(a, (function(e, t) {
                            return "" !== e.title ? '<tr data-dt-row="' + e.rowIndex + '" data-dt-column="' + e.columnIndex + '"><td>' + e.title + ":</td> <td>" + e.data + "</td></tr>" : ""
                        })).join("");
                        return !!s && $('<table class="table"/><tbody />').append(s)
                    }
                }
            }
        });
        $(".dataTables_length").addClass("mt-0 mt-md-3 me-3"), $(".dt-action-buttons").addClass("pt-0"), $(".dt-buttons > .btn-group > button").removeClass("btn-secondary")
    }
    $(".datatables-order tbody").on("click", ".delete-record", (function() {
        o.row($(this).parents("tr")).remove().draw()
    })), setTimeout((() => {
        $(".dataTables_filter .form-control").removeClass("form-control-sm"), $(".dataTables_length .form-select").removeClass("form-select-sm")
    }), 300)
}));