"use strict";let assetsPath=document.documentElement.getAttribute("data-assets-path"),templateName=document.documentElement.getAttribute("data-template"),rtlSupport=!0;
