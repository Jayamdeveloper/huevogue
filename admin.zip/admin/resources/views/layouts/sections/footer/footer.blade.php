<!-- Footer-->
<footer class="content-footer footer bg-footer-theme">
    
  <div class="{{ (!empty($containerNav) ? $containerNav : 'container-fluid') }} d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column footer-sub-con">
    
    <div class="mb-2 mb-md-0">
        
        Copyright  © Hue Vogue <script>document.write(new Date().getFullYear())</script>. All Rights Reserved
    
    </div>
    
    <div>
        <a href="https://jayamwebsolutions.com/" target="_blank" class="text-dark position-relative">Developed by Jayam Web Solutions</a>
    </div>
    
  </div>
  
</footer>
<!--/ Footer-->
