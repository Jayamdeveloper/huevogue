
<?php $__env->startSection('layoutContent'); ?>
<script src="<?php echo e(asset('assets/js/app-ecommerce-product-add.js')); ?>"></script>

<!-- Content wrapper -->
<div class="content-wrapper">

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">

        <h4 class="py-3 mb-4">
            <span class="text-muted fw-light">Products /</span><span> Add Product</span>
        </h4>

        <div class="app-ecommerce">

            <!-- Add Product -->
            <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">

                <div class="d-flex flex-column justify-content-center">
                    <h4 class="mb-1 mt-3">Add a new Product</h4>
                    <p class="text-muted">Orders placed across your store</p>
                </div>
                <div class="d-flex align-content-center flex-wrap gap-3">
                    <button class="btn btn-label-secondary">Discard</button>
                    <button class="btn btn-label-primary">Save draft</button>
                    <button type="submit" class="btn btn-primary">Publish product</button>
                </div>

            </div>

            <div class="row">

                <!-- First column-->
                <div class="col-12 col-lg-8">

                    <!-- Product Information -->
                    <div class="card mb-4">

                        <div class="card-header">
                            <h5 class="card-tile mb-0">Product information</h5>
                        </div>

                        <div class="card-body">

                            <div class="mb-3">
                                <label class="form-label" for="ecommerce-product-name">Name</label>
                                <input type="text" class="form-control" id="ecommerce-product-name" placeholder="Product title" name="productTitle" aria-label="Product title">
                            </div>

                            <!-- Description -->
                            <div>
                                <label class="form-label">Description</label>
                                <div class="form-control p-0 pt-1">

                                    <div class="comment-editor border-0 pb-4" id="product-description">
                                    </div>

                                    <!-- </div> -->
                                </div>
                            </div>

                            <div class="mb-2 mt-3">
                                <label for="formFileMultiple" class="form-label">Product Image</label>
                                <input class="form-control" type="file" id="formFileMultiple" multiple="">
                            </div>
                        </div>

                    </div>
                    <!-- /Product Information -->

                </div>
                <!-- /Second column -->

                <!-- Second column -->
                <div class="col-12 col-lg-4">
                    <!-- Pricing Card -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Pricing</h5>
                        </div>
                        <div class="card-body">
                            <!-- Base Price -->
                            <div class="mb-3">
                                <label class="form-label" for="ecommerce-product-price">Base Price</label>
                                <input type="number" class="form-control" id="ecommerce-product-price" placeholder="Price" name="productPrice" aria-label="Product price">
                            </div>
                            <!-- Discounted Price -->
                            <div class="mb-3">
                                <label class="form-label" for="ecommerce-product-discount-price">Discounted
                                    Price</label>
                                <input type="number" class="form-control" id="ecommerce-product-discount-price" placeholder="Discounted Price" name="productDiscountedPrice" aria-label="Product discounted price">
                            </div>
                            <div class="mb-3">
                                <label class="form-label" for="ecommerce-product-discount-price">Shipping Cost </label>
                                <input type="number" class="form-control" id="ecommerce-product-discount-price" placeholder="Free or Order Value Based" name="productDiscountedPrice" aria-label="Product discounted price">
                            </div>
                            <!-- Charge tax check box -->
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="" id="price-charge-tax" checked>
                                <label class="form-label" for="price-charge-tax">
                                    Charge tax on this product
                                </label>
                            </div>
                            <!-- Instock switch -->
                            <div class="d-flex justify-content-between align-items-center border-top pt-3">
                                <span class="mb-0 h6">In stock</span>
                                <div class="w-25 d-flex justify-content-end">
                                    <label class="switch switch-primary switch-sm me-4 pe-2">
                                        <input type="checkbox" class="switch-input" checked="">
                                        <span class="switch-toggle-slider">
                                            <span class="switch-on">
                                                <span class="switch-off"></span>
                                            </span>
                                        </span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /Pricing Card -->

                </div>
                <!-- /Second column -->


                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-tile mb-0">Meta Tags <span class="text-muted"> ( Optional ) </span></h5>
                        </div>

                        <div class="card-body">

                            <div class="mb-3">
                                <label class="form-label" for="ecommerce-product-name">Meta Title</label>
                                <input type="text" class="form-control" id="ecommerce-product-name" placeholder="Product title" name="productTitle" aria-label="Product title">
                            </div>

                            <div class="mb-3">
                                <label class="form-label" for="ecommerce-product-name">Keywords</label>
                                <input type="text" class="form-control" id="ecommerce-product-name" placeholder="Product title" name="productTitle" aria-label="Product title">
                            </div>

                            <div class="mb-3">
                                <label class="form-label" for="ecommerce-product-name">Description</label>
                                <input type="text" class="form-control" id="ecommerce-product-name" placeholder="Product title" name="productTitle" aria-label="Product title">
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- / Content -->


    <script>
        var quill = new Quill('#product-description', {
            modules: {
                toolbar: [
                    [{
                        header: [1, 2, false]
                    }],
                    ['bold', 'italic', 'underline'],
                    ['image', 'code-block']
                ]
            },
            placeholder: 'Compose an epic...',
            theme: 'snow' // or 'bubble'
        });
    </script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.commonMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\hue-vogue\admin\resources\views/admin-products/add-edit-product.blade.php ENDPATH**/ ?>