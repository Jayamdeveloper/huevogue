<!-- BEGIN: Vendor JS-->
<!-- <script src="<?php echo e(asset(('assets/vendor/libs/jquery/jquery.js'))); ?>"></script> -->
<script src="<?php echo e(asset(('assets/vendor/libs/popper/popper.js'))); ?>"></script>
<script src="<?php echo e(asset(('assets/vendor/js/bootstrap.js'))); ?>"></script>
<script src="<?php echo e(asset(('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js'))); ?>"></script>
<script src="<?php echo e(asset(('assets/vendor/libs/hammer/hammer.js'))); ?>"></script>
<script src="<?php echo e(asset(('assets/vendor/libs/typeahead-js/typeahead.js'))); ?>"></script>


<script src="<?php echo e(asset(('assets/vendor/js/menu.js'))); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>



<script src="<?php echo e(asset(('assets/vendor/libs/quill/katex.js'))); ?>"></script>
<script src="<?php echo e(asset(('assets/vendor/libs/quill/quill.js'))); ?>"></script>

<script src="<?php echo e(asset('assets/vendor/libs/select2/select2.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/dropzone/dropzone.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/jquery-repeater/jquery-repeater.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/flatpickr/flatpickr.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/ui-cards-analytics.js')); ?>"></script>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.45.2/apexcharts.min.js"></script> -->
<!-- <script src="<?php echo e(asset('assets/vendor/libs/tagify/tagify.js')); ?>"></script> -->

<script src="<?php echo e(asset('assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>






<?php echo $__env->yieldContent('vendor-script'); ?>
<!-- END: Page Vendor JS-->
<!-- BEGIN: Theme JS-->
<script src="<?php echo e(asset(('assets/js/main.js'))); ?>"></script>

<!-- END: Theme JS-->
<!-- Pricing Modal JS-->
<?php echo $__env->yieldPushContent('pricing-script'); ?>
<!-- END: Pricing Modal JS-->
<!-- BEGIN: Page JS-->
<?php echo $__env->yieldContent('page-script'); ?>
<!-- END: Page JS--><?php /**PATH D:\xampp\htdocs\hue-vogue\admin\resources\views/layouts/sections/scripts.blade.php ENDPATH**/ ?>