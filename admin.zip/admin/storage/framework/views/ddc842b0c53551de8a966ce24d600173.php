
<?php $__env->startSection('layoutContent'); ?>


<!-- Content wrapper -->
<div class="content-wrapper">

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">

        <h4 class="py-3 mb-4">
            <span class="text-muted fw-light">Products /</span> Product List
        </h4>


        <!-- Product List Table -->
        <div class="card">
            <div class="card-header">
                <!--<h5 class="card-title">Filter</h5>-->
                <div class="d-flex justify-content-between align-items-center row py-3 gap-3 gap-md-0">
                    <div class="col-md-4 product_status"></div>
                    <div class="col-md-4 product_category"></div>
                    <div class="col-md-4 product_stock"></div>
                </div>
            </div>
            <div class="card-datatable table-responsive">
                <table class="datatables-products table border-top">
                    <thead>
                        <tr>
                            <th>S.no</th>
                            <th>Image</th>
                            <th class="text-nowrap">product Name</th>
                            <th class="text-nowrap">stock</th>
                            <th>Description</th>
                            <th>price</th>
                            <th>qty</th>
                            <th>status</th>
                            <th>actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <tr>
                            <td>1</td>
                            <td>
                               <img src="https://www.webdevelopmentindia.co.in/hue-vogue/web4/assets/img/product1.png" style="width:50px;">
                            </td>
                            <td>Supreme Polishing Treatment</td>
                            <td class="text-nowrap">In Stock</td>
                            <td>When using a beard serum, it's typically applied....</td>
                            <td>$40</td>
                            <td>100</td>
                            <td>Active</td>
                            <td>
                               <div class="d-flex">
                                   
                                   <button class="btn btn-info me-2">
                                       <i class="fa-regular fa-eye"></i>
                                   </button>
                                   
                                    <a  href="https://www.webdevelopmentindia.co.in/hue-vogue/admin/public/admin/products/create" class="btn btn-primary me-2">
                                       <i class="fa-solid fa-pen-to-square"></i>
                                   </a>
                                   
                                   <button class="btn btn-danger">
                                       <i class="fa-solid fa-trash-can"></i>
                                   </button>
                                   
                               </div>
                            </td>
                        </tr>
                        
                        <tr>
                            <td>2</td>
                            <td>
                                <img src="https://www.webdevelopmentindia.co.in/hue-vogue/web4/assets/img/product2.png" style="width:50px;">
                            </td>
                            <td>Beard Growth Serum</td>
                            <td class="text-nowrap">Out of Stock</td>
                            <td>When using a beard serum, it's typically applied...</td>
                            <td>$30</td>
                            <td>80</td>
                            <td>Active</td>
                            <td>
                               <div class="d-flex">
                                   
                                   <button class="btn btn-info me-2">
                                       <i class="fa-regular fa-eye"></i>
                                   </button>
                                   
                                   <a  href="https://www.webdevelopmentindia.co.in/hue-vogue/admin/public/admin/products/create" class="btn btn-primary me-2">
                                       <i class="fa-solid fa-pen-to-square"></i>
                                   </a>
                                   
                                   <button class="btn btn-danger">
                                       <i class="fa-solid fa-trash-can"></i>
                                   </button>
                                   
                               </div>
                            </td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
        </div>


    </div>
    <!-- / Content -->

    <!--<script src="<?php echo e(asset('assets/js/app-ecommerce-product-list.js')); ?>"></script>-->

    <script>
        $(document).ready(function() {



            var table = $('.datatables').DataTable({
                lengthChange: false,
                buttons: ['copy', 'excel', 'pdf', 'colvis']
            });

            table.buttons().container()
                .appendTo('#example_wrapper .col-md-6:eq(0)');
        });
    </script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.commonMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/webdevelop/public_html/hue-vogue/admin/resources/views/admin-products/list-products.blade.php ENDPATH**/ ?>